export default function UtilisateurPage() {
  return (
    <div>
      <h1>Test de redirection</h1>
    </div>
  )
}
